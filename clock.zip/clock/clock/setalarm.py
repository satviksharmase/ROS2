import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from datetime import datetime

class MinimalSubscriber(Node):

    def __init__(self):
        super().__init__('minimal_subscriber')        
        self.publisher_ = self.create_publisher(String, 'clock/setalarm', 10)
        timer_period = 1
        self.timer = self.create_timer(timer_period, self.timer_callback)
        time=input("input time in format HH:MM:SS : ")
        alarm_time=datetime.strptime(time,"%H:%M:%S")
        self.i = alarm_time
        self.j = datetime.now()
        
    def timer_callback(self):
        msg = String()
        msg.data = '%s:%s:%s' %(self.i.hour,self.i.minute,self.i.second)
        current_time = '%s:%s:%s' %(self.j.hour,self.j.minute,self.j.second)
        self.publisher_.publish(msg)
        if current_time < msg.data:
        	self.get_logger().info('alarm at: "%s"' % msg.data)
        
        self.subscription = self.create_subscription(
            String,
            'clock/alarm',
            self.listener_callback,
            10)
        self.subscription  

    def listener_callback(self, msg):
        self.get_logger().info('The alarm rang at:"%s"'%msg.data)
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
	
    minimal_subscriber = MinimalSubscriber()
    rclpy.spin(minimal_subscriber)
    minimal_subscriber.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()


import rclpy
from rclpy.node import Node
import pyowm
from std_msgs.msg import String

class MinimalSubscriber(Node):

    def __init__(self):
        super().__init__('minimal_subscriber')
        self.subscription = self.create_subscription(
            String,
            'weather/request',
            self.listener_callback,
            10)
        self.subscription
         
    def listener_callback(self, msg):
    	self.get_logger().info('weather today at "%s":' % msg.data)
    	owm = pyowm.OWM('7642e9c9e6ff5e359f79dd90ca636acb')
    	mng = owm.weather_manager()
    	obs = mng.weather_at_place(msg.data).weather.temperature('celsius')
    	
    	location = 'weather/%s' % msg.data
    	if obs is not None:
    		self.publisher_ = self.create_publisher(String,location, 10)
    		mag = String()
    		self.publisher_.publish(mag)
    		self.get_logger().info('\n"%s"' % (obs))
    		rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)

    minimal_subscriber = MinimalSubscriber()
    rclpy.spin(minimal_subscriber)
    minimal_subscriber.destroy_node()
    
    rclpy.shutdown()

if __name__ == '__main__':
    main()


